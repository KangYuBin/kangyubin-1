//�������� 1��
public class ex1 {

	public static void main(String args[]) {
		for (int i = 0; i <= 4; i++) {
	         for (int j = 0; j <= i; j++) {
	            System.out.print("*");
	         }
	         
	         System.out.println();
	      }
		
		System.out.println("-------------");
		   int num=5;
		      for (int i = 0; i <= 4; i++) {
		         for (int j = num; j >0; j--) {
		            System.out.print("*");
		         }
		         num--;
		         System.out.println();
		      }
		System.out.println("-------------");
		 int k = 0;
	      for(int i = 0; i < 5; i++)         
	      {
	         if(i < 3) k++;               
	         else     k--;               
	         for(int j = 0; j < k; j++)      
	         {
	            System.out.print("*");
	         }
	         System.out.print("\n");            
	      }
	}
}
