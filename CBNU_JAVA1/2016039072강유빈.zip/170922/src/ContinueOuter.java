//ContinueOuter ���α׷�

public class ContinueOuter {
	public static void main(String[] args) {
		int i=0;
		
		outloop:
			while(i<3) {
				for(int j=0;j<5;j++) {
					System.out.println("i:"+i+"-j:"+j);
					if(j==2){
						i++;
						continue outloop;}
				}
			}
	}
}
